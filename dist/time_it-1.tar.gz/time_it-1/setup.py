
from setuptools import setup, find_packages


setup(
    name='time_it',
    version='1',
    license='MIT',
    author="Code Blanco",
    author_email='email@example.com',
    description="Package for timing python",
    url='https://github.com/CodeBlanco/python-module-time_it',
    keywords='time it',
    install_requires=[
      ],

)
